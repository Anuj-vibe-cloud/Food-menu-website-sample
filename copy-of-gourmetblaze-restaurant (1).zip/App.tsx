
import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import MenuSection from './components/MenuSection';
import Footer from './components/Footer';
import { FOOD_CATEGORIES } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col font-poppins bg-gradient-to-br from-slate-900 via-black to-slate-900">
      <Navbar />
      <main className="flex-grow">
        <HeroSection />
        <MenuSection id="menu" title="Our Culinary Delights" categories={FOOD_CATEGORIES} />
        {/* Add more sections as needed, e.g., About Us, Testimonials */}
      </main>
      <Footer />
    </div>
  );
};

export default App;